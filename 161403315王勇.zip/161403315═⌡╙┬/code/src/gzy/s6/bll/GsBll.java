package gzy.s6.bll;
import gzy.s6.model.*;
import gzy.s6.dal.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Calendar;
import java.util.Scanner;

public class GsBll {

	public User[] users=new User[2];
	public Goods[] goods=new Goods[999];
	public Record[] records=new Record[100];
	private int level;
	GsDal gd=new GsDal();
	
	Scanner in=new  Scanner(System.in);
	//������

	public int getLevel()
	{
		return level;
	}
	public void setLevel(int lel)
	{
		this.level=lel;
	}

	
	//ϵͳ��ʼ��
	public void Init()
	{
		users[0]=new User("kaoshi100ha","123456",1,"����Ե","118114");
		users[1]=new User("kaoshi200ha","123456",0,"����","119120");
		goods[0]=new Goods("�Ϻü���Ƭ",1,0,80,6);
		goods[1]=new Goods("��������Ь",2,1,15,210);
		goods[2]=new Goods("��èϴ�ྫ",3,2,40,15);
		goods[3]=new Goods("���۱ʼǱ�",4,3,5,8000);
		goods[4]=new Goods("�ƺ�¥����",5,4,25,40);
		goods[5]=new Goods("����ӡ��ֽ",6,2,50,25);
		for(int i=6;i<goods.length;i++)
		{
			goods[i]=new Goods();
		}
		for(int i=0;i<records.length;i++)
		{
			records[i]=new Record();
		}
		try 
		{
			ObjectOutputStream os;
			os = new ObjectOutputStream(
					new FileOutputStream("user.txt"));
			for(int i=0;i<users.length;i++)
				os.writeObject(users[i]);
			os.close();
			os=new ObjectOutputStream(
					new FileOutputStream("goods.txt"));
			for(int i=0;i<goods.length;i++)
				os.writeObject(goods[i]);
			os.close();
			os=new ObjectOutputStream(
					new FileOutputStream("records.txt"));
			for(int i=0;i<records.length;i++)
				os.writeObject(records[i]);
			os.close();
		}
		catch (IOException e) 
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}	
		
	}
	
	//��������Ʒ
	public void addGoods(String name,int id,int cg,int stock,int price)
	{
		gd.addGoods(name, id, cg, stock, price);
		
	}
	//��֤�˺���ȷ��
	public int checkAccount(String account,String password)
	{
		int flag=0;
		users=gd.getUser();
		for(int i=0;i<users.length;i++)
		//	if(account.equals("")&&password.equals(""))
			if(account.equals(users[i].getAccount())&&password.equals(users[i].getPassword()))
				{
					flag=1;
				//	setLevel(users[i].getLevel());
					break;
				}
		if(flag==1)		
			return 1;
		else
			return 0;
		
	}
	public Goods[] getAllGoods()
	{
		return gd.getGoods();
		
	}
	public Goods[] getCgGoods(int n)
	{
		int i,j;
		goods=gd.getGoods();
		Goods[] newgoods=new Goods[999];
		for(i=0,j=0;i<goods.length;i++)
			if(goods[i].getCategory()==n)
			{
				newgoods[j]=goods[i];
				j++;
			}
		for(i=j;i<newgoods.length;i++)
		{
			newgoods[i]=new Goods();
		}
		return newgoods;
	}
	public int ifFindGoods(int id)
	{
		int iffind=0;
		goods=gd.getGoods();
		for(int i=0;i<goods.length;i++)
		{
			if(id==goods[i].getId())
			{
				iffind=1;
				break;
			}
		}
		return iffind;
	}
	

	
	public int getQueryGoodsID(int id)
	{
		return gd.getQueryGoodsID(id);
	}
	//�ж�������Ʒ������
		public int checkAddGoods(String name,int id,int cg)
		{
			int flag=1;
			goods=gd.getGoods();
			if(id<=0)
			{
				
				flag=0;
			}
			else
			{
				if(cg!=0&&cg!=1&&cg!=2&&cg!=3&&cg!=4)
				{
					
					flag=0;
				}
				else
				{
					for(int i=0;goods[i].getId()!=0;i++)
					{
						if(id==goods[i].getId())
						{
							
							flag=0;
							break;
						}
						else if(name.equals(goods[i].getName()))
						{
							
							flag=0;
							break;
						}
					}
				}	
			}
			if(flag==1)		//����������
				return 1;
			else			//������������
				return 0;
		}
		
//�޸���Ʒ��Ϣ
	public void updateGoods(int id,String name,int cg,int price,int stock,int i)
	{
		gd.updateGoods(id, name, cg, price, stock, i);	
	}
		
//�ж�����Ʒ��Ϣ�ܷ������޸�
	public int checkUpdateGoods(String name,int id,int cg,int j)

	{
		int flag=1;
		goods=gd.getGoods();
		if(id<=0)
		{
		
			flag=0;
		}
		else
		{
			if(cg!=0&&cg!=1&&cg!=2&&cg!=3&&cg!=4)
			{
		
				flag=0;
			}
			else
			{
				for(int i=0;goods[i].getId()!=0;i++)
				{
					if(i==j)
					{
						continue;
					}
					else
					{
						if(id==goods[i].getId())
						{
						
							flag=0;
							break;
						}
						else if(name.equals(goods[i].getName()))
						{
						
							flag=0;
							break;
						}
					}
					
				}
			}	
		}
		if(flag==1)		//����������
			return 1;
		else			//������������
			return 0;
	}
	
//ɾ����Ʒ
	public void deleteGoods(int i)
	{
		gd.deleteGoods(i);
		
	}
	public Record[] getRecords()
	{
		return gd.getRecords();
	}
	
	public void addRecord(int i,int ch,int number)
	{

		goods=gd.getGoods();
		String temp;
		Calendar cal=Calendar.getInstance(); 
		int y=cal.get(Calendar.YEAR);      
		int m=cal.get(Calendar.MONTH);      
		int d=cal.get(Calendar.DATE); 
		int h=cal.get(Calendar.HOUR);
		int mi=cal.get(Calendar.MINUTE);
		int s=cal.get(Calendar.SECOND);
		if(ch==0)
		{
			temp=y+"��"+m+"��"+d+"��"+h+"ʱ"+mi+"��"+s+"�룬"+goods[i].getName()+"������"+
					Integer.toString(Math.abs(number))+"��,"+"Ŀǰ���Ϊ��"+Integer.toString(goods[i].getStock());
			gd.addRecord(temp);
		}
		else if(ch==1)
		{
			temp=y+"��"+m+"��"+d+"��"+h+"ʱ"+mi+"��"+s+"�룬"+goods[i].getName()+"�����"+
					Integer.toString(Math.abs(number))+"��,"+"Ŀǰ���Ϊ��"+Integer.toString(goods[i].getStock());
			gd.addRecord(temp);
			
		}
	}
	
	public int checkAddStock(int ch,int number,int i)
	{
		goods=gd.getGoods();
		if((ch==0)&&(number>goods[i].getStock()))
			return 0;
		else
			return 1;
	}
	
	public void addStock(int ch,int number,int i)
	{
		gd.addStock(ch, number, i);
	}
	
}
