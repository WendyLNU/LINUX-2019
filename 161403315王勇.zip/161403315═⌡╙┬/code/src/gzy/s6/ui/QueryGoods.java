package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class QueryGoods extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

			public void run() {
				try {
					QueryGoods frame = new QueryGoods();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}


	/**
	 * Create the frame.
	 */
	public QueryGoods() {
		setTitle("\u5546\u54C1\u5E93\u5B58\u7BA1\u7406\u7CFB\u7EDF");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u57FA\u672C\u4FE1\u606F\u67E5\u8BE2");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		lblNewLabel.setBounds(300, 10, 240, 50);
		contentPane.add(lblNewLabel);
		
		JLabel lblInformationQuery = new JLabel("Information Query");
		lblInformationQuery.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblInformationQuery.setBounds(330, 59, 186, 43);
		contentPane.add(lblInformationQuery);
		
		JButton button = new JButton("1.\u98DF\u54C1\u7C7B");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				QueryGoods2 a=new QueryGoods2(0);
				a.run(0);	
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button.setBounds(295, 112, 250, 50);
		contentPane.add(button);
		
		JButton button_1 = new JButton("2.\u670D\u88C5\u7C7B");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				QueryGoods2 a=new QueryGoods2(1);
				a.run(1);
			}
		});
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_1.setBounds(295, 172, 250, 50);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("3.\u65E5\u7528\u54C1\u7C7B");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				QueryGoods2 a=new QueryGoods2(2);
				a.run(2);
			}
		});
		button_2.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_2.setBounds(295, 232, 250, 50);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("4.\u6570\u7801\u7C7B");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				QueryGoods2 a=new QueryGoods2(3);
				a.run(3);
			}
		});
		button_3.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_3.setBounds(295, 292, 250, 50);
		contentPane.add(button_3);
		
		JButton button_4 = new JButton("5.\u5176\u4ED6\u7C7B");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				QueryGoods2 a=new QueryGoods2(4);
				a.run(4);
			}
		});
		button_4.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_4.setBounds(295, 352, 250, 50);
		contentPane.add(button_4);
		
		JButton button_5 = new JButton("\u8FD4\u56DE");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				InfoMenu a=new InfoMenu();
				a.run();
			}
		});
		button_5.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_5.setBounds(706, 385, 121, 50);
		contentPane.add(button_5);
	}

}
