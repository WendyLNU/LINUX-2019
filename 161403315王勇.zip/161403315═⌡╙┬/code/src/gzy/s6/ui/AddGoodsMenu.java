package gzy.s6.ui;
import gzy.s6.bll.*;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Label;

import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;

public class AddGoodsMenu extends JFrame {

	private JPanel contentPane;
	private JTextField txtn;
	private JTextField txtna;
	private JTextField txts;
	private JTextField txtp;
	String name;
	int id;
	int cg;
	int stock;
	int price;
	int flag=1;

	/**
	 * Launch the application.
	 */

			public void run() {
				try {
					AddGoodsMenu frame = new AddGoodsMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}


	/**
	 * Create the frame.
	 */
	public AddGoodsMenu() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u6DFB\u52A0\u65B0\u5546\u54C1");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		label.setBounds(343, 10, 156, 50);
		contentPane.add(label);
		
		JLabel lblAddNewGoods = new JLabel("Add New Goods");
		lblAddNewGoods.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblAddNewGoods.setBounds(334, 52, 178, 50);
		contentPane.add(lblAddNewGoods);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lblNewLabel.setBounds(142, 118, 108, 39);
		contentPane.add(lblNewLabel);
		
		txtn = new JTextField();
		txtn.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txtn.setBounds(241, 120, 132, 33);
		contentPane.add(txtn);
		txtn.setColumns(10);
		
		JLabel tx = new JLabel("\u5546 \u54C1 \u540D \uFF1A");
		tx.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		tx.setBounds(442, 118, 108, 39);
		contentPane.add(tx);
		
		txtna = new JTextField();
		txtna.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txtna.setColumns(10);
		txtna.setBounds(541, 120, 132, 33);
		contentPane.add(txtna);
		
		JLabel label_2 = new JLabel("\u5546\u54C1\u5E93\u5B58\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_2.setBounds(142, 188, 108, 39);
		contentPane.add(label_2);
		
		txts = new JTextField();
		txts.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txts.setColumns(10);
		txts.setBounds(241, 190, 132, 33);
		contentPane.add(txts);
		
		JLabel label_3 = new JLabel("\u5546\u54C1\u4EF7\u683C\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_3.setBounds(442, 188, 108, 39);
		contentPane.add(label_3);
		
		txtp = new JTextField();
		txtp.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txtp.setColumns(10);
		txtp.setBounds(541, 190, 132, 33);
		contentPane.add(txtp);
		
		JLabel label_4 = new JLabel("\u5546\u54C1\u5E93\u5B58\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_4.setBounds(142, 255, 108, 39);
		contentPane.add(label_4);
		
		JRadioButton ck0 = new JRadioButton("\u98DF\u54C1\u7C7B");
		ck0.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck0.setBounds(241, 263, 93, 23);
		contentPane.add(ck0);
		
		JRadioButton ck1 = new JRadioButton("\u670D\u88C5\u7C7B");
		ck1.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck1.setBounds(343, 263, 93, 23);
		contentPane.add(ck1);
		
		JRadioButton ck2 = new JRadioButton("\u65E5\u7528\u54C1\u7C7B");
		ck2.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck2.setBounds(442, 263, 108, 23);
		contentPane.add(ck2);
		
		JRadioButton ck3 = new JRadioButton("\u6570\u7801\u7C7B");
		ck3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck3.setBounds(560, 263, 93, 23);
		contentPane.add(ck3);
		
		JRadioButton ck4 = new JRadioButton("\u5176\u4ED6\u7C7B");
		ck4.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck4.setBounds(661, 263, 93, 23);
		contentPane.add(ck4);
		
		 ButtonGroup group = new ButtonGroup ();
		 group.add (ck1);
		 group.add (ck2);
		 group.add (ck3);
		 group.add (ck4);
		 group.add (ck0);
		 
		 class CheckHandle implements ItemListener
			{
				public void itemStateChanged(ItemEvent e)
				{
					Object s=e.getSource();
					if(s==ck0)
					{
							cg=0;
					}
					if(s==ck1)
					{
							cg=1;
					}
					if(s==ck2)
					{
							cg=2;
					}
					if(s==ck3)
					{
							cg=3;
					}
					if(s==ck4)
					{
							cg=4;
					}
				}
			}
			
			ck0.addItemListener(new CheckHandle());
			ck1.addItemListener(new CheckHandle());
			ck2.addItemListener(new CheckHandle());
			ck3.addItemListener(new CheckHandle());
			ck4.addItemListener(new CheckHandle());
		 
		
		JButton btok = new JButton("\u63D0\u4EA4");
		btok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GsBll a=new GsBll();
				name=txtna.getText();
				id=Integer.parseInt(txtn.getText());
				stock=Integer.parseInt(txts.getText());
				price=Integer.parseInt(txtp.getText());
				flag=a.checkAddGoods(name, id, cg);
				if(flag==1)
				{
					a.addGoods(name, id, cg, stock, price);
					JDialog dg=new JDialog();
					dg.setBounds(545,280,350,125);
					dg.getContentPane().setLayout(new FlowLayout());
					Label lble=new Label("                  ������Ʒ�ɹ���             ");
					lble.setFont(new Font("",0,20)); 
					Button okbt=new Button("ȷ��");
					okbt.setFont(new Font("",0,20));
					okbt.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							dg.dispose();
							dispose();
							InfoMenu a=new InfoMenu();
							a.run();
						}
					}
							);
					dg.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e)
						{
							dg.dispose();
							dispose();
							InfoMenu a=new InfoMenu();
							a.run();
						}
					});
					dg.getContentPane().add(lble);
					dg.getContentPane().add(okbt);
					dg.setVisible(true);
					
				}
				else
				{
					JDialog dg=new JDialog();
					dg.setBounds(545,280,350,125);
					dg.getContentPane().setLayout(new FlowLayout());
					Label lble=new Label("   ����ʧ�ܣ������¼����Ʒ��Ϣ��");
					lble.setFont(new Font("",0,20));
					Button okbt=new Button("ȷ��");
					okbt.setFont(new Font("",0,20));
					okbt.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							dg.dispose();
							
						}
					}
							);
					dg.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e)
						{
							dg.dispose();
							
						}
					});
					dg.getContentPane().add(lble);
					dg.getContentPane().add(okbt);
					dg.setVisible(true);
				}

			}
				
		});
		btok.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btok.setBounds(356, 334, 134, 50);
		contentPane.add(btok);
		
		JButton btbk = new JButton("\u8FD4\u56DE");
		btbk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				InfoMenu a=new InfoMenu();
				a.run();
			}
		});
		btbk.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btbk.setBounds(706, 385, 121, 50);
		contentPane.add(btbk);
	}
}
