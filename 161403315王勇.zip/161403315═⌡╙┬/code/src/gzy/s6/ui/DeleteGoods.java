package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import gzy.s6.model.*;
import gzy.s6.bll.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTextField;

public class DeleteGoods extends JFrame {

	private JPanel contentPane;
	private JTextField txta;
	String name;
	int id;
	int cg;
	int stock;
	int price;
	int flag=1;
	int i; 
	int ifq=0;
	Goods[] goods=new Goods[999];
	/**
	 * Launch the application.
	 */

			public void run() {
				try {
					DeleteGoods frame = new DeleteGoods();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}


	/**
	 * Create the frame.
	 */
	public DeleteGoods() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u5220\u9664\u5DF2\u6709\u5546\u54C1");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		label.setBounds(320, 10, 197, 50);
		contentPane.add(label);
		
		JLabel lblDeleteGoods = new JLabel("Delete Goods");
		lblDeleteGoods.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblDeleteGoods.setBounds(337, 53, 147, 50);
		contentPane.add(lblDeleteGoods);
		
		JLabel label_1 = new JLabel("\u8BF7\u8F93\u5165\u8981\u5220\u9664\u7684\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_1.setBounds(142, 118, 240, 39);
		contentPane.add(label_1);
		
		JButton btq = new JButton("\u67E5\u8BE2");
		btq.setFont(new Font("΢���ź�", Font.PLAIN, 23));
		btq.setBounds(550, 120, 123, 39);
		contentPane.add(btq);
		
		JLabel label_2 = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_2.setBounds(142, 194, 108, 39);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u5546 \u54C1 \u540D \uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_3.setBounds(437, 194, 108, 39);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("\u5546\u54C1\u5E93\u5B58\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_4.setBounds(142, 277, 108, 39);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u5546\u54C1\u4EF7\u683C\uFF1A");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_5.setBounds(350, 277, 108, 39);
		contentPane.add(label_5);
		
		txta = new JTextField();
		txta.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txta.setColumns(10);
		txta.setBounds(375, 120, 141, 33);
		contentPane.add(txta);
		
		JLabel lbn = new JLabel("");
		lbn.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbn.setBounds(244, 194, 108, 39);
		contentPane.add(lbn);
		
		JLabel lbna = new JLabel("");
		lbna.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbna.setBounds(541, 194, 108, 39);
		contentPane.add(lbna);
		
		JLabel lbs = new JLabel("");
		lbs.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbs.setBounds(233, 277, 78, 39);
		contentPane.add(lbs);
		
		JLabel lbp = new JLabel("");
		lbp.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbp.setBounds(439, 277, 78, 39);
		contentPane.add(lbp);
		
		JLabel lb = new JLabel("\u5546\u54C1\u7C7B\u522B\uFF1A");
		lb.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lb.setBounds(565, 277, 108, 39);
		contentPane.add(lb);
		
		JLabel lbc = new JLabel("");
		lbc.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbc.setBounds(654, 277, 78, 39);
		contentPane.add(lbc);
		
		JButton btok = new JButton("\u63D0\u4EA4");
		btok.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btok.setBounds(343, 362, 134, 50);
		contentPane.add(btok);
		
		JButton btbk = new JButton("\u8FD4\u56DE");
		btbk.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btbk.setBounds(706, 385, 121, 50);
		contentPane.add(btbk);
		
		btq.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ifq=1;
				id=Integer.parseInt(txta.getText());
				GsBll gb=new GsBll();
				if(id<=0||gb.ifFindGoods(id)==0)
				{
					JDialog dg=new JDialog();
					dg.setBounds(545,280,350,125);
					dg.setLayout(new FlowLayout());
					Label lble=new Label(" ��Ʒ���������������²�����");
					lble.setFont(new Font("",0,20));
					Button okbt=new Button("ȷ��");
					okbt.setFont(new Font("",0,20));
					okbt.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							dg.dispose();
							txta.setText("");
						}
					});
					dg.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e)
						{
							dg.dispose();
							txta.setText("");
						}
					});
					dg.add(lble);
					dg.add(okbt);
					dg.setVisible(true);
				}
				else
				{
					goods=gb.getAllGoods();
					lbn.setText(Integer.toString(goods[gb.getQueryGoodsID(id)].getId()));
					lbna.setText(goods[gb.getQueryGoodsID(id)].getName());
					lbp.setText(Integer.toString(goods[gb.getQueryGoodsID(id)].getPrice()));
					lbs.setText(Integer.toString(goods[gb.getQueryGoodsID(id)].getStock()));
					if(goods[gb.getQueryGoodsID(id)].getCategory()==0)
					{
						lbc.setText("ʳƷ��");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==1)
					{
						lbc.setText("��װ��");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==2)
					{
						lbc.setText("����Ʒ��");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==3)
					{
						lbc.setText("������");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==4)
					{
						lbc.setText("������");
					}
				}
			}
			
		});
		
		btok.addActionListener(new ActionListener() 
		{

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
			if(ifq==1)
			{
				JDialog dg=new JDialog();
				dg.setBounds(545,280,350,125);
				dg.setLayout(new FlowLayout());
				Label lble=new Label("               ��ȷ��Ҫɾ������Ʒ��             ");
				lble.setFont(new Font("",0,20)); 
				Button okbt=new Button("ȷ��");
				okbt.setFont(new Font("",0,20));
				Button nobt=new Button("ȡ��");
				nobt.setFont(new Font("",0,20));
				dg.add(lble);
				dg.add(okbt);
				dg.add(nobt);
				okbt.addActionListener(new ActionListener() 
				{

					@Override
					public void actionPerformed(ActionEvent e) 
					{
						// TODO Auto-generated method stub
						GsBll a=new GsBll();
						a.deleteGoods(a.getQueryGoodsID(id));
						dg.dispose();
						JDialog dg1=new JDialog();
						dg1.setBounds(545,280,350,125);
						dg1.setLayout(new FlowLayout());
						Label lble1=new Label("                  ��Ʒɾ���ɹ���             ");
						lble1.setFont(new Font("",0,20)); 
						Button okbt1=new Button("ȷ��");
						okbt1.setFont(new Font("",0,20));
						okbt1.addActionListener(new ActionListener() 
						{

							@Override
							public void actionPerformed(ActionEvent e) 
							{
								// TODO Auto-generated method stub
								dg1.dispose();
								dispose();
								InfoMenu a=new InfoMenu();
								a.run();
							}
						});
						dg1.addWindowListener(new WindowAdapter() 
						{
							public void windowClosing(WindowEvent e)
							{
								dg1.dispose();
								dispose();
								InfoMenu a=new InfoMenu();
								a.run();
							}
						});
						dg1.add(lble1);
						dg1.add(okbt1);
						dg1.setVisible(true);
					}
					
				});
				dg.addWindowListener(new WindowAdapter() 
				{
					public void windowClosing(WindowEvent e)
					{
						dg.dispose();
						
					}
				});
				nobt.addActionListener(new ActionListener() 
				{

					@Override
					public void actionPerformed(ActionEvent arg0) {
						// TODO Auto-generated method stub
						dg.dispose();
					}
					
				});
				dg.setVisible(true);
			}
			}
		});
		
		btbk.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				StockMenu a =new StockMenu();
				a.run();
			}
			
		});
		
	}

}
