package gzy.s6.ui;
import gzy.s6.model.*;
import gzy.s6.bll.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class QueryGoods2 extends JFrame {

	private JPanel contentPane;
	public Goods[] goods=new Goods[999];
	int number;

 //   String tableColunms[][] = new String[number][columnNames.length];
 
	/**
	 * Launch the application.
	 */

		public void run(int n) {
				try {
					
					
					QueryGoods2 frame = new QueryGoods2(n);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

	/**
	 * Create the frame.
	 */
	public QueryGoods2(int n) {
		
		GsBll gb=new GsBll();
		goods=gb.getCgGoods(n);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u57FA\u672C\u4FE1\u606F\u67E5\u8BE2");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		lblNewLabel.setBounds(300, 10, 240, 50);
		contentPane.add(lblNewLabel);
		
		JLabel lblInformationQuery = new JLabel("Information Query");
		lblInformationQuery.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblInformationQuery.setBounds(330, 59, 186, 43);
		contentPane.add(lblInformationQuery);
		
		JButton button_5 = new JButton("\u8FD4\u56DE");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				QueryGoods a=new QueryGoods();
				a.run();
			}
		});
		button_5.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_5.setBounds(706, 385, 121, 50);
		contentPane.add(button_5);
		for(number=0;goods[number].getId()!=0;number++)
		{
			
		}
		String[] columnNames = {"��Ʒ���","��Ʒ��","��Ʒ���","��Ʒ�۸�"};
		Object[][] obj=new Object[999][4];
		for(int i=0;i<number;i++)
			for(int j=0;j<4;j++)
			{
					switch(j)
					{
						case 0:
							obj[i][j]=goods[i].getId();
							break;
						case 1:
							obj[i][j]=goods[i].getName();
							break;
						case 2:
							obj[i][j]=goods[i].getStock();
							break;
						case 3:
							obj[i][j]=goods[i].getPrice();
							break;
					}

			}
			
		
		JTable table = new JTable(obj,columnNames);
		table.setBounds(153, 112, 551, 253);
		DefaultTableCellRenderer r = new DefaultTableCellRenderer(); 
		r.setHorizontalAlignment(JLabel.CENTER); 
		table.setDefaultRenderer(Object.class, r);
		table.setRowHeight(25);
		JScrollPane scrollpane=new JScrollPane(table);
		scrollpane.setBounds(153, 112, 551, 253);
		contentPane.add(scrollpane);

		

	}

}
