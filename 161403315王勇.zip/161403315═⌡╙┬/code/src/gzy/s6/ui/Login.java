package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.EventQueue;
import gzy.s6.bll.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Label;
import java.awt.FlowLayout;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Window.Type;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	GsBll gb=new GsBll();
	/**
	 * Launch the application.
	 */
	public void run() 
	{
		try 
		{
			Login frame = new Login();
			frame.setVisible(true);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Create the frame.
	 */
	public Login() {
		setResizable(false);
		setTitle("\u5546\u54C1\u5E93\u5B58\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_title = new JPanel();
		panel_title.setBounds(10, 66, 807, 149);
		contentPane.add(panel_title);
		panel_title.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblNewLabel = new JLabel("\u2606\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2606");
		lblNewLabel.setFont(new Font("��������", Font.PLAIN, 20));
		panel_title.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u4E28\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u4E28");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_1.setFont(new Font("��������", Font.PLAIN, 20));
		panel_title.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u4E28\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u6B22\u8FCE\u8FDB\u5165\u5546\u54C1\u5E93\u5B58\u7BA1\u7406\u7CFB\u7EDF\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u4E28");
		lblNewLabel_2.setFont(new Font("��������", Font.PLAIN, 20));
		panel_title.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u4E28\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u4E28");
		lblNewLabel_3.setFont(new Font("��������", Font.PLAIN, 20));
		panel_title.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\u2606\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2014\u2606");
		lblNewLabel_4.setFont(new Font("��������", Font.PLAIN, 20));
		panel_title.add(lblNewLabel_4);
		
		JPanel panel_user = new JPanel();
		panel_user.setBounds(10, 212, 807, 223);
		contentPane.add(panel_user);
		panel_user.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("\u8D26  \u53F7\uFF1A");
		lblNewLabel_5.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		lblNewLabel_5.setBounds(77, 32, 113, 38);
		panel_user.add(lblNewLabel_5);
		
		textField = new JTextField();
		textField.setFont(new Font("����", Font.PLAIN, 20));
		textField.setBounds(188, 34, 277, 38);
		panel_user.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u5BC6  \u7801\uFF1A");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		label.setBounds(77, 80, 113, 38);
		panel_user.add(label);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("����", Font.PLAIN, 20));
		passwordField.setBounds(188, 82, 277, 38);
		panel_user.add(passwordField);
		
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			//	gb.Init();
				String account;
				String password;
				account=textField.getText();
				password=String.valueOf(passwordField.getPassword());
				if(gb.checkAccount(account, password)==1)
				{
					dispose();
					MainMenu mm=new MainMenu();
					mm.run();
				}
				else
				{
					//Dialog dg=new Dialog(login,"��ʾ",true);
					JDialog dg=new JDialog();
					dg.setBounds(545,280,350,125);
					dg.getContentPane().setLayout(new FlowLayout());
					Label lble=new Label("   �˺Ż���������������������룡");
					lble.setFont(new Font("",0,20));
					Button okbt=new Button("ȷ��");
					okbt.setFont(new Font("",0,20));
					okbt.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							dg.dispose();	
							textField.setText("");
							passwordField.setText("");
						}
					}
							);
					dg.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e)
						{
							dg.dispose();
						}
					});
					dg.getContentPane().add(lble);
					dg.getContentPane().add(okbt);
					dg.setVisible(true);
				}
				
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 26));
		btnNewButton.setBounds(534, 32, 193, 86);
		panel_user.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("���ߣ�����");
		lblNewLabel_6.setBounds(626, 187, 171, 26);
		panel_user.add(lblNewLabel_6);
	}
	private static class __Tmp {
		private static void __tmp() {
			  javax.swing.JPanel __wbp_panel = new javax.swing.JPanel();
		}
	}
}
