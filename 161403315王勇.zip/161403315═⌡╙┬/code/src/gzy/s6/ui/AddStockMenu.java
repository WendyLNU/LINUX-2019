package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import gzy.s6.bll.*;
import gzy.s6.model.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JRadioButton;

public class AddStockMenu extends JFrame {

	private JPanel contentPane;
	private JTextField txta;
	private JTextField txtsn;
	String name;
	int id;
	int cg;
	int stock;
	int price;
	int flag=1;
	int i;
	int ifq1=0,ifq2=0;
	int number,ch;			//ch=0������;ck=1:���
	public Goods[] goods=new Goods[999];
	GsBll gb=new GsBll();

	/**
	 * Launch the application.
	 */

			public void run() {
				try {
					AddStockMenu frame = new AddStockMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

	/**
	 * Create the frame.
	 */
	public AddStockMenu() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u5546\u54C1\u51FA\u5165\u5E93\u7BA1\u7406");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		label.setBounds(321, 10, 251, 50);
		contentPane.add(label);
		
		JLabel lblStockManagement = new JLabel("Stock Management");
		lblStockManagement.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblStockManagement.setBounds(337, 57, 189, 50);
		contentPane.add(lblStockManagement);
		
		JLabel label_1 = new JLabel("\u8BF7\u8F93\u5165\u8981\u64CD\u4F5C\u7684\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_1.setBounds(163, 117, 240, 39);
		contentPane.add(label_1);
		
		txta = new JTextField();
		txta.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txta.setColumns(10);
		txta.setBounds(396, 119, 141, 33);
		contentPane.add(txta);
		
		JButton btq = new JButton("\u67E5\u8BE2");
		btq.setFont(new Font("΢���ź�", Font.PLAIN, 23));
		btq.setBounds(571, 119, 123, 39);
		contentPane.add(btq);
		
		JLabel label_2 = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_2.setBounds(163, 183, 108, 39);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u5546 \u54C1 \u540D \uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_3.setBounds(458, 183, 108, 39);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("\u5546\u54C1\u5E93\u5B58\uFF1A");
		label_4.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_4.setBounds(163, 240, 108, 39);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("\u5546\u54C1\u4EF7\u683C\uFF1A");
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_5.setBounds(371, 240, 108, 39);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("\u5546\u54C1\u7C7B\u522B\uFF1A");
		label_6.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_6.setBounds(586, 240, 108, 39);
		contentPane.add(label_6);
		
		JLabel lbn = new JLabel("");
		lbn.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbn.setBounds(267, 183, 108, 39);
		contentPane.add(lbn);
		
		JLabel lbna = new JLabel("");
		lbna.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbna.setBounds(564, 183, 108, 39);
		contentPane.add(lbna);
		
		JLabel lbs = new JLabel("");
		lbs.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbs.setBounds(256, 240, 78, 39);
		contentPane.add(lbs);
		
		JLabel lbp = new JLabel("");
		lbp.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbp.setBounds(462, 240, 78, 39);
		contentPane.add(lbp);
		
		JLabel lbc = new JLabel("");
		lbc.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lbc.setBounds(677, 240, 78, 39);
		contentPane.add(lbc);
		
		JLabel label_7 = new JLabel("\u8BF7\u786E\u5B9A\u60A8\u5BF9\u8BE5\u5546\u54C1\u7684\u64CD\u4F5C\u53CA\u6570\u91CF\uFF1A");
		label_7.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_7.setBounds(163, 299, 316, 39);
		contentPane.add(label_7);
		
		JRadioButton ck0 = new JRadioButton("\u51FA\u5E93");
		ck0.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck0.setBounds(472, 307, 71, 23);
		contentPane.add(ck0);
		
		JRadioButton ck1 = new JRadioButton("\u5165\u5E93");
		ck1.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		ck1.setBounds(545, 307, 71, 23);
		contentPane.add(ck1);
		
		ButtonGroup group = new ButtonGroup ();
		 group.add (ck1);
		 group.add (ck0);
		
		 class CheckHandle implements ItemListener
			{
				public void itemStateChanged(ItemEvent e)
				{
					Object s=e.getSource();
					if(s==ck0)
					{
							ch=0;	
					}
					if(s==ck1)
					{
							ch=1;
					}
				}
			}
			ck0.addItemListener(new CheckHandle());
			ck1.addItemListener(new CheckHandle());
			
		txtsn = new JTextField();
		txtsn.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		txtsn.setColumns(10);
		txtsn.setBounds(622, 303, 88, 33);
		contentPane.add(txtsn);
		
		JLabel label_8 = new JLabel("\u4EF6");
		label_8.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		label_8.setBounds(729, 299, 37, 39);
		contentPane.add(label_8);
		
		JButton btok = new JButton("\u63D0\u4EA4");
		btok.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btok.setBounds(355, 359, 134, 50);
		contentPane.add(btok);
		
		JButton btbk = new JButton("\u8FD4\u56DE");
		btbk.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btbk.setBounds(706, 385, 121, 50);
		contentPane.add(btbk);
		
		btq.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ifq1=1;
				id=Integer.parseInt(txta.getText());
				GsBll gb=new GsBll();
				if(id<=0||gb.ifFindGoods(id)==0)
				{
					JDialog dg=new JDialog();
					dg.setBounds(545,280,350,125);
					dg.getContentPane().setLayout(new FlowLayout());
					Label lble=new Label(" ��Ʒ���������������²�����");
					lble.setFont(new Font("",0,20));
					Button okbt=new Button("ȷ��");
					okbt.setFont(new Font("",0,20));
					okbt.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							dg.dispose();
							txta.setText("");
						}
					});
					dg.addWindowListener(new WindowAdapter() {
						public void windowClosing(WindowEvent e)
						{
							dg.dispose();
							txta.setText("");
						}
					});
					dg.getContentPane().add(lble);
					dg.getContentPane().add(okbt);
					dg.setVisible(true);
				}
				else
				{
					goods=gb.getAllGoods();
					lbn.setText(Integer.toString(goods[gb.getQueryGoodsID(id)].getId()));
					lbna.setText(goods[gb.getQueryGoodsID(id)].getName());
					lbp.setText(Integer.toString(goods[gb.getQueryGoodsID(id)].getPrice()));
					lbs.setText(Integer.toString(goods[gb.getQueryGoodsID(id)].getStock()));
					if(goods[gb.getQueryGoodsID(id)].getCategory()==0)
					{
						lbc.setText("ʳƷ��");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==1)
					{
						lbc.setText("��װ��");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==2)
					{
						lbc.setText("����Ʒ��");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==3)
					{
						lbc.setText("������");
					}
					else if(goods[gb.getQueryGoodsID(id)].getCategory()==4)
					{
						lbc.setText("������");
					}
				}
			}
			
		});
		
		btok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) 
			{
				// TODO Auto-generated method stub
				if(ifq1==1)
				{
					number=Integer.parseInt(txtsn.getText());
					if(number<=0)
					{
						JDialog dg=new JDialog();
						dg.setBounds(545,280,350,125);
						dg.getContentPane().setLayout(new FlowLayout());
						Label lble=new Label("  ������������������������룡");
						lble.setFont(new Font("",0,20));
						Button okbt=new Button("ȷ��");
						okbt.setFont(new Font("",0,20));
						okbt.addActionListener(new ActionListener() {

							@Override
							public void actionPerformed(ActionEvent e) {
								// TODO Auto-generated method stub
								dg.dispose();
								txtsn.setText("");
							}
						});
						dg.addWindowListener(new WindowAdapter() {
							public void windowClosing(WindowEvent e)
							{
								dg.dispose();
								txtsn.setText("");
							}
						});
						dg.getContentPane().add(lble);
						dg.getContentPane().add(okbt);
						dg.setVisible(true);
					}
					else
					{
						if(gb.checkAddStock(ch, number, gb.getQueryGoodsID(id))==0)
						{
							JDialog dg=new JDialog();
							dg.setBounds(545,280,350,125);
							dg.getContentPane().setLayout(new FlowLayout());
							Label lble=new Label(" ����Ʒ�������㣬�����²�����");
							lble.setFont(new Font("",0,20));
							Button okbt=new Button("ȷ��");
							okbt.setFont(new Font("",0,20));
							okbt.addActionListener(new ActionListener() {

								@Override
								public void actionPerformed(ActionEvent e) {
									// TODO Auto-generated method stub
									dg.dispose();
									txtsn.setText("");
								}
							});
							dg.addWindowListener(new WindowAdapter() {
								public void windowClosing(WindowEvent e)
								{
									dg.dispose();
									txtsn.setText("");
								}
							});
							dg.getContentPane().add(lble);
							dg.getContentPane().add(okbt);
							dg.setVisible(true);
						}
						else
						{
							gb.addStock(ch, number, gb.getQueryGoodsID(id));
							gb.addRecord(gb.getQueryGoodsID(id),ch,number);
							JDialog dg=new JDialog();
							dg.setBounds(545,280,350,125);
							dg.getContentPane().setLayout(new FlowLayout());
							Label lble=new Label();
							if(ch==0)
								lble.setText("                 ��Ʒ����ɹ���             ");
							else
								lble.setText("                 ��Ʒ���ɹ���             ");
							lble.setFont(new Font("",0,20)); 
							Button okbt=new Button("ȷ��");
							okbt.setFont(new Font("",0,20));
							okbt.addActionListener(new ActionListener() {

								@Override
								public void actionPerformed(ActionEvent e) {
									// TODO Auto-generated method stub
									dg.dispose();
									dispose();
									StockMenu a=new StockMenu();
									a.run();
								}
							}
									);
							dg.addWindowListener(new WindowAdapter() {
								public void windowClosing(WindowEvent e)
								{
									dg.dispose();
									dispose();
									StockMenu a=new StockMenu();
									a.run();
								}
							});
							dg.getContentPane().add(lble);
							dg.getContentPane().add(okbt);
							dg.setVisible(true);
						}
					}
					

				}
				else
				{
				}
			}
			
		});
		
		btbk.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
				StockMenu a =new StockMenu();
				a.run();
			}
			
		});
	}
}
