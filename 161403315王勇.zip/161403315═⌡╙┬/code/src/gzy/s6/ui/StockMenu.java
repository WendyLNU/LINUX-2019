package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StockMenu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	public void run() 
	{
		try 
		{
			StockMenu frame = new StockMenu();
			frame.setVisible(true);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public StockMenu() {
		setResizable(false);
		setTitle("\u5546\u54C1\u5E93\u5B58\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u51FA\u5165\u5E93\u7BA1\u7406");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		lblNewLabel.setBounds(300, 10, 220, 50);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Inventory Management");
		lblNewLabel_1.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(300, 58, 220, 50);
		contentPane.add(lblNewLabel_1);
		
		JButton button = new JButton("1.\u5546\u54C1\u51FA\u5165\u5E93\u7BA1\u7406");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				AddStockMenu a =new AddStockMenu();
				a.run();
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button.setBounds(267, 113, 284, 65);
		contentPane.add(button);
		
		JButton button_1 = new JButton("2.\u5546\u54C1\u51FA\u5165\u5E93\u8BB0\u5F55\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				RecordMenu a=new RecordMenu();
				a.run();
			}
		});
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_1.setBounds(267, 204, 284, 65);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("0.\u8FD4\u56DE\u4E3B\u83DC\u5355");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				MainMenu a=new MainMenu();
				a.run();
			}
		});
		button_2.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_2.setBounds(267, 299, 284, 65);
		contentPane.add(button_2);
	}

}
