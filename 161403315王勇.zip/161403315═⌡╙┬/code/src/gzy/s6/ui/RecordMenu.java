package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import gzy.s6.bll.*;
import gzy.s6.model.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RecordMenu extends JFrame {

	private JPanel contentPane;
	public Record[] records=new Record[100];
	GsBll gb=new GsBll();
	int number;
	/**
	 * Launch the application.
	 */

			public void run() {
				try {
					RecordMenu frame = new RecordMenu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}


	/**
	 * Create the frame.
	 */
	public RecordMenu() {
		records=gb.getRecords();
		for(number=0;records[number].getRecord()!=null;number++)
		{
		
		}
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u5546\u54C1\u51FA\u5165\u5E93\u8BB0\u5F55\u67E5\u8BE2");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		label.setBounds(294, 10, 279, 50);
		contentPane.add(label);
		
		JLabel lblStockmenu = new JLabel("Stock Record");
		lblStockmenu.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblStockmenu.setBounds(360, 55, 150, 50);
		contentPane.add(lblStockmenu);
		
		String[] columnNames = {"��¼���","��¼����"};
		Object[][] obj=new Object[100][2];
		for(int i=0;i<number;i++)
			for(int j=0;j<2;j++)
			{
					switch(j)
					{
						case 0:
							obj[i][j]=records[i].getID();
							break;
						case 1:
							obj[i][j]=records[i].getRecord();
							break;
					}

			}
			
		
		JTable table = new JTable(obj,columnNames);
		table.setBounds(153, 112, 551, 253);
		DefaultTableCellRenderer r = new DefaultTableCellRenderer(); 
		r.setHorizontalAlignment(JLabel.CENTER); 
		table.setDefaultRenderer(Object.class, r);
		table.setRowHeight(25);
		table.getColumnModel().getColumn(0).setPreferredWidth(81);
		table.getColumnModel().getColumn(1).setPreferredWidth(470);
		JScrollPane scrollpane=new JScrollPane(table);
		scrollpane.setBounds(153, 112, 551, 253);
		contentPane.add(scrollpane);
		
		JButton button = new JButton("\u8FD4\u56DE");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				StockMenu a =new StockMenu();
				a.run();
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button.setBounds(706, 385, 121, 50);
		contentPane.add(button);
	}

}
