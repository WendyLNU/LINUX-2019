package gzy.s6.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainMenu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public void run() 
	{
		try 
		{
			MainMenu frame = new MainMenu();
			frame.setVisible(true);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public MainMenu() {
		setResizable(false);
		setTitle("\u5546\u54C1\u5E93\u5B58\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(305, 100, 843, 474);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u4E3B \u83DC \u5355");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		lblNewLabel.setBounds(362, 10, 133, 50);
		contentPane.add(lblNewLabel);
		
		JLabel lblMainMenu = new JLabel("Main Menu");
		lblMainMenu.setFont(new Font("University Roman LET", Font.PLAIN, 25));
		lblMainMenu.setBounds(368, 52, 103, 50);
		contentPane.add(lblMainMenu);
		
		JButton btnNewButton = new JButton("1.\u5546\u54C1\u57FA\u672C\u4FE1\u606F\u7BA1\u7406");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				InfoMenu a=new InfoMenu();
				a.run();
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		btnNewButton.setBounds(279, 112, 284, 65);
		contentPane.add(btnNewButton);
		
		JButton button = new JButton("2.\u5546\u54C1\u51FA\u5165\u5E93\u7BA1\u7406");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				StockMenu a=new StockMenu();
				a.run();
			}
		});
		button.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button.setBounds(279, 204, 284, 65);
		contentPane.add(button);
		
		JButton button_1 = new JButton("0.\u9000\u51FA");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 25));
		button_1.setBounds(279, 295, 284, 65);
		contentPane.add(button_1);
	}
}
