package gzy.s6.dal;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import gzy.s6.model.*;


public class GsDal
{

	public User[] users=new User[2];
	public Goods[] goods=new Goods[999];
	public Record[] records=new Record[100];
	
	public User[] getUser()
	{
		try
		{
			ObjectInputStream is=new ObjectInputStream(new FileInputStream("user.txt"));
			for(int i=0;i<users.length;i++)
				users[i]=(User)is.readObject();
			is.close();
		}
		catch (IOException e) 
		{  
            e.printStackTrace();  
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		return users;
	}
	
	public Goods[] getGoods()
	{
		try
		{
			ObjectInputStream is=new ObjectInputStream(new FileInputStream("goods.txt"));
			for(int i=0;i<goods.length;i++)
				goods[i]=(Goods) is.readObject();
			is.close();
		}
		catch (IOException e) 
		{  
            e.printStackTrace();  
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		return goods;
		
	}
	
	public Record[] getRecords()
	{
		try
		{
			ObjectInputStream is=new ObjectInputStream(new FileInputStream("records.txt"));
			for(int j=0;j<records.length;j++)
				records[j]=(Record) is.readObject();
			is.close();
		}
		catch (IOException e) 
		{  
            e.printStackTrace();  
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		
		return records;
		
	}
	
	public void saveRecords(Record[] records)
	{
		try 
		{
			ObjectOutputStream os;
			os=new ObjectOutputStream(
					new FileOutputStream("records.txt"));
			for(int j=0;j<records.length;j++)
				os.writeObject(records[j]);
			os.close();
		}
		catch (IOException e) 
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}	
	}
	
	public void saveGoods(Goods[] goods)
	{
		try 
		{
			ObjectOutputStream os;
			os=new ObjectOutputStream(
					new FileOutputStream("goods.txt"));
			for(int j=0;j<goods.length;j++)
				os.writeObject(goods[j]);
			os.close();
		}
		catch (IOException e) 
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}	
		
		
	}
	
	
	public int getQueryGoodsID(int id)
	{
		goods=getGoods();
		int i;
		for(i=0;i<goods.length;i++)
		{
			if(id==goods[i].getId())
			{
				break;
			}
		}
		return i;
	}
		
	public void deleteGoods(int i)
	{
		goods=getGoods();
		for(int j=i;goods[j].getId()!=0;j++)
		{
			goods[j].setId(goods[j+1].getId());
			goods[j].setName(goods[j+1].getName());
			goods[j].setCategory(goods[j+1].getCategory());
			goods[j].setPrice(goods[j+1].getPrice());
			goods[j].setStock(goods[j+1].getStock());
		}
		saveGoods(goods);
	}
	
	public void addGoods(String name,int id,int cg,int stock,int price)
	{
		int i;
		goods=getGoods();
		for(i=0;goods[i].getId()!=0;i++)
			;
		goods[i].setName(name);
		goods[i].setId(id);
		goods[i].setCategory(cg);
		goods[i].setStock(stock);
		goods[i].setPrice(price);
		saveGoods(goods);
	}
	
	public void updateGoods(int id,String name,int cg,int price,int stock,int i)
	{
		goods=getGoods();
		goods[i].setName(name);
		goods[i].setId(id);
		goods[i].setCategory(cg);
		goods[i].setStock(stock);
		goods[i].setPrice(price);
		saveGoods(goods);
	}
	
	public void addStock(int ch,int number,int i)
	{
		goods=getGoods();
		if(ch==0)
			goods[i].setStock(goods[i].getStock()-number);
		else
			goods[i].setStock(goods[i].getStock()+number);
		saveGoods(goods);
	}
	
	public void addRecord(String st)
	{
		int n;
		records=getRecords();
		for(n=0;records[n].getID()!=0;n++)
			;
		records[n].setRecord(st);
		records[n].setID(n+1);
		saveRecords(records);
	}
}