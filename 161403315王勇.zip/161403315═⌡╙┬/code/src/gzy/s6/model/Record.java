package gzy.s6.model;

import java.io.Serializable;

public class Record implements Serializable {

	private String record;
	private int id;

	public Record(int id, String record) {
		this.id = id;
		this.record = record;
	}

	public Record() {

	}

	public int getID() {
		return id;

	}

	public String getRecord() {
		return record;
	}

	public void setRecord(String record) {
		this.record = record;
	}

	public void setID(int id) {
		this.id = id;
	}

}
