package gzy.s6.model;
import gzy.s6.ui.*;

public class J2016112359S6T1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login login=new Login();
		login.run();
	}

}
